package com.example.firebaserd;

public class User {

    String firstName, lastName, age;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAge() {
        return age;
    }
}